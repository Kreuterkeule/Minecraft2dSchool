-------------Dman49's MineCraft 2d Texture Pack v1.0----------

Hello all! This is Dman49's MineCraft 2d Texture pack!

This is a texture pack for the 2d game "MineCraft" for PSP
(from the PSP Genesis Competition). The textures were taken
from the original game "MineCraft" from Mojang.

--------------------------------------------------------------
		       > Installation <

1. Open "ms0:PSP/GAME/MineCraft/Pix" and drop the file 
   "D49 MC Pack", located in this zip file, there.
2. Go into the game and from the main menu, change "theme"
   to "D49 MC Pack".
3. Enjoy

*Note: when you switch the theme you will probably experience
 a freeze screen. This is normal, just turn off your PSP
 and load the game again. When you get to the game, the
 texture pack will be activated.*

--------------------------------------------------------------

*********************** NOTES ********************************
-This version of Dman49's Texture Pack has been updated
 Thurs.May 12th.2011 - For use with "Minecraft Revision 3"
-I wasn't able to make "Block" textures work, except for
 Aluminium


-Check out http://www.moddb.com/members/dman49   for updates,
 more mods and PSP stuff!
**************************************************************


Thanks again, and I hope I made your game a little bit better!
- Dman49